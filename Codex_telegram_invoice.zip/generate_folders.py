import os
import pandas as pd

df = pd.read_excel("Telegram_Chat_IDs.xlsx")

def clean(name):
    return ''.join(c for c in str(name) if c.isalnum() or c in ' _-').strip().replace(" ", "_")[:100]

for name in df["Название"]:
    folder_name = clean(name)
    if folder_name:
        os.makedirs(folder_name, exist_ok=True)
