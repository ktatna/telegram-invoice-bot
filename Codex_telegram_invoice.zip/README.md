# Codex Test Project: Telegram Invoice Bot

## 📝 Задача (на русском):
Есть Excel-файл со списком клиентов (на русском языке), в котором указаны названия и Telegram ID.
Нужно:
- создать папки на диске (например, в Google Drive или локально) по этим названиям;
- исключить проблему "кракозябр" при создании;
- можно использовать Python или доработанный .bat-файл.

## 💡 Что не сработало:
- .bat-файл в UTF-8 → Windows создаёт папки с иероглифами.
- .bat в Windows-1251 тоже не работает на Google Drive.

## 🧠 Что нужно:
- либо Python-скрипт, который создаёт папки с русскими именами корректно;
- либо объяснение, как правильно создать такие папки в Google Drive через API.

---

## 📝 Task (in English):
You have an Excel file with Russian client names and Telegram IDs.
Goal:
- Create folders based on those names (e.g. in Google Drive or locally);
- Avoid broken character encoding (garbled folder names);
- Use Python or fix the .bat file properly.

What failed:
- `.bat` in UTF-8 = broken folder names.
- `.bat` in Windows-1251 still doesn't work via Google Drive mount.

Help needed:
- Either a working Python solution;
- Or guidance for creating folders with correct names in Google Drive via API.
